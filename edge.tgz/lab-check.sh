#!/usr/bin/env bash
# =============================================================================
# lab-check.sh — Contrôle qualité FORMATEUR d'une VM EDGE01 avant clonage.
# EXCLUSIVEMENT formateur : ne doit JAMAIS rester sur la VM remise à l'étudiant
# (il contient le mot de passe de spray et teste toute la solution).
#
#   sudo bash lab-check.sh            # contrôle complet, résumé lisible
#   sudo bash lab-check.sh --strict   # sort en erreur (code 1) au premier FAILED
#
# À lancer :
#   - sur l'image dorée APRÈS seed-*.sh + --harden (dernier contrôle avant template) — SANS reboot,
#   - puis sur un CLONE de test (démarré via qm start),
#   - le test « survie après reboot complet » se fait sur ce CLONE jetable, JAMAIS sur la maître
#     (un reboot de la maître après --harden figerait une identité unique sur tous les clones).
# Après usage, SUPPRIMER ce fichier de la VM :  shred -u /root/lab-check.sh
# =============================================================================
set -uo pipefail

need_root(){ [ "$(id -u)" -eq 0 ] || { echo "à lancer en root (sudo)."; exit 1; }; }
need_root

STRICT=0; [ "${1:-}" = "--strict" ] && STRICT=1
FAIL=0
INIT_PW='Orvalis2026!'          # secret formateur (spray) — d'où : ne pas laisser ce fichier sur la VM
DOMAIN="orvalis.lan"
SSHO="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ConnectTimeout=5 -o PreferredAuthentications=password -o PubkeyAuthentication=no"

# result LABEL OK|FAILED [raison]
result(){
  local label="$1" status="$2" reason="${3:-}" width=22 dots
  dots="$(printf '%*s' $((width - ${#label})) '' | tr ' ' '.')"
  if [ "$status" = "OK" ]; then
    printf '%s %s OK\n' "$label" "$dots"
  else
    printf '%s %s FAILED — %s\n' "$label" "$dots" "$reason"; FAIL=1
    [ "$STRICT" -eq 1 ] && { echo; echo ">>> STRICT : arrêt au premier échec."; exit 1; }
  fi
}

echo "=== EDGE01 — contrôle qualité formateur ==="

# --- NETWORK : hostname edge01 + une IPv4 hors loopback --------------------
h="$(hostname 2>/dev/null || true)"; ip4="$(hostname -I 2>/dev/null | tr ' ' '\n' | grep -v '^127\.' | head -1)"
if [ "$h" = "edge01" ] && [ -n "$ip4" ]; then result "NETWORK" OK
else result "NETWORK" FAILED "hostname='$h' ip='$ip4' (attendu edge01 + IPv4)"; fi

# --- SSH : port 22 + auth par mot de passe active --------------------------
if (exec 3<>/dev/tcp/127.0.0.1/22) 2>/dev/null; then exec 3>&- || true
  if sshd -T 2>/dev/null | grep -qi '^passwordauthentication yes'; then result "SSH" OK
  else result "SSH" FAILED "PasswordAuthentication non actif (couche accès ?)"; fi
else result "SSH" FAILED "port 22 fermé"; fi

# --- WEB MAIN : site public 80 + robots + HTTPS 443 (SAN) ------------------
idx="$(curl -fs http://127.0.0.1/ 2>/dev/null || true)"
rob="$(curl -fs http://127.0.0.1/robots.txt 2>/dev/null || true)"
san="$(echo | openssl s_client -connect 127.0.0.1:443 -servername portail.$DOMAIN 2>/dev/null | openssl x509 -noout -text 2>/dev/null || true)"
if grep -qi 'ORVALIS' <<<"$idx" && grep -q '/admin' <<<"$rob" && grep -q "portail.$DOMAIN" <<<"$san"; then
  result "WEB MAIN" OK
else result "WEB MAIN" FAILED "index/robots/HTTPS-SAN incomplet"; fi

# --- WEB LEGACY : ancien portail 8080 --------------------------------------
leg="$(curl -fs http://127.0.0.1:8080/ 2>/dev/null || true)"
grep -qi 'v1.2' <<<"$leg" && result "WEB LEGACY" OK || result "WEB LEGACY" FAILED "8080 ne sert pas le portail v1.2"

# --- SMB : public visible + transfert$ listé et refusé en invité -----------
shares="$(smbclient -L //127.0.0.1/ -N 2>/dev/null || true)"
tdeny="$(smbclient //127.0.0.1/transfert\$ -N -c 'ls' 2>&1 || true)"
if grep -q 'public' <<<"$shares" && grep -q 'transfert' <<<"$shares" \
   && grep -qiE 'NT_STATUS_ACCESS_DENIED|NT_STATUS_LOGON_FAILURE' <<<"$tdeny"; then
  result "SMB" OK
else result "SMB" FAILED "public/transfert$ ou refus invité KO"; fi

# --- RECON ARTIFACTS : procédure, annuaire, PDF méta, vhost, snmp, dir caché
proc="$(smbclient //127.0.0.1/public -N -c 'get procedure.txt -' 2>/dev/null || true)"
ann="$(smbclient //127.0.0.1/public -N -c 'get annuaire_interne.csv -' 2>/dev/null || true)"
pdfmeta="$(smbclient //127.0.0.1/public -N -c 'get note_service.pdf -' 2>/dev/null | grep -a '/Author' || true)"
vhost="$(curl -fs -H "Host: portail.$DOMAIN" http://127.0.0.1/ 2>/dev/null || true)"
snmp="$(snmpget -v2c -c public -t 2 -r 1 127.0.0.1 sysName.0 2>/dev/null || true)"
hidden="$(curl -fs http://127.0.0.1/portail-rh-old/ 2>/dev/null || true)"
cfg="$(curl -fs http://127.0.0.1/backup/config.php.bak 2>/dev/null || true)"
if grep -qi 'p.nom' <<<"$proc" && grep -q 'c.girard' <<<"$ann" && grep -q 's.meyer' <<<"$pdfmeta" \
   && grep -qi 'Portail RH' <<<"$vhost" && grep -q 'edge01' <<<"$snmp" \
   && grep -qi 'Ancienne interface' <<<"$hidden" && grep -q 'db.orvalis.lan' <<<"$cfg"; then
  result "RECON ARTIFACTS" OK
else result "RECON ARTIFACTS" FAILED "un artefact manque (procédure/annuaire/méta/vhost/snmp/dir/config)"; fi

# --- ACCESS PATH : 3 comptes tombent, DSI+admin résistent, foothold != root
if command -v sshpass >/dev/null 2>&1; then
  aok=1; u=""
  for u in p.durand l.fontaine m.petit; do
    grep -q 'uid=' <<<"$(sshpass -p "$INIT_PW" ssh $SSHO "$u"@127.0.0.1 id 2>/dev/null || true)" || aok=0
  done
  for u in s.meyer k.benali; do
    grep -q 'uid=' <<<"$(sshpass -p "$INIT_PW" ssh $SSHO "$u"@127.0.0.1 id 2>/dev/null || true)" && aok=0
  done
  fuid="$(sshpass -p "$INIT_PW" ssh $SSHO p.durand@127.0.0.1 'id -u' 2>/dev/null || true)"
  [ -n "$fuid" ] && [ "$fuid" != "0" ] || aok=0
  [ "$aok" -eq 1 ] && result "ACCESS PATH" OK || result "ACCESS PATH" FAILED "matrice 3/2 ou foothold-non-root KO"
else result "ACCESS PATH" FAILED "sshpass absent (installé au provisionnement)"; fi

# --- PRIVESC PATH : groupe maint + sudo find + trophée 600 + root atteignable
pok=1
for u in p.durand l.fontaine m.petit; do
  id -nG "$u" 2>/dev/null | tr ' ' '\n' | grep -qx maint || pok=0
done
visudo -cf /etc/sudoers.d/10-maint-find >/dev/null 2>&1 || pok=0
grep -q 'uid=0' <<<"$(runuser -u p.durand -- sudo -n /usr/bin/find /etc/hostname -maxdepth 0 -exec id \; 2>/dev/null || true)" || pok=0
[ -f /root/rapport_confidentiel.txt ] && [ -z "$(runuser -u p.durand -- cat /root/rapport_confidentiel.txt 2>/dev/null || true)" ] || pok=0
[ "$pok" -eq 1 ] && result "PRIVESC PATH" OK || result "PRIVESC PATH" FAILED "groupe/sudoers/root/trophée KO"

# --- LOGGING : auth.log présent + journalisation active --------------------
if [ -f /var/log/auth.log ] && { systemctl is-active rsyslog >/dev/null 2>&1 || systemctl is-active systemd-journald >/dev/null 2>&1; }; then
  result "LOGGING" OK
else result "LOGGING" FAILED "auth.log ou service de log absent"; fi

# --- REBOOT READY : les services reviennent après reboot (is-enabled) ------
renabled=1
for s in ssh nginx smbd snmpd; do systemctl is-enabled "$s" >/dev/null 2>&1 || renabled=0; done
[ "$renabled" -eq 1 ] && result "REBOOT READY" OK || result "REBOOT READY" FAILED "un service n'est pas enabled"

# --- SEED LEAK : aucun script seed ni secret formateur ne doit subsister ----
leak=""
sf="$(find / -xdev -type f -name 'seed-*.sh' 2>/dev/null | head -5)"
[ -n "$sf" ] && leak="scripts seed présents"
[ -f /root/edge01-access-secrets.txt ] && leak="${leak:+$leak; }secrets accès présents"
[ -f /etc/orvalis-edge01.access.seeded ] && leak="${leak:+$leak; }marqueur access présent"
[ -z "$leak" ] && result "SEED LEAK" OK || result "SEED LEAK" FAILED "$leak"

# --- SPOILER CHECK : pas de solution en clair hors emplacements prévus ------
scan_dirs="/home /root /tmp /var/tmp /opt /srv /etc /var/log /var/backups /var/www"
spoil=""
# NB : --exclude lab-check.sh sinon ce script (qui CONTIENT le secret et 'FLAG{')
# se détecterait lui-même. Il n'est de toute façon pas censé rester sur la VM.
grep -rIl --exclude-dir=orvalis --exclude='lab-check.sh' "$INIT_PW" $scan_dirs 2>/dev/null | head -1 | grep -q . \
  && spoil="mot de passe de spray en clair"
# le FLAG ne doit exister QUE dans le trophée root 600 (illisible sans root)
flagfiles="$(grep -rIl --exclude='lab-check.sh' 'FLAG{' $scan_dirs 2>/dev/null | grep -v '^/root/rapport_confidentiel.txt$' | head -1)"
[ -n "$flagfiles" ] && spoil="${spoil:+$spoil; }FLAG hors trophée ($flagfiles)"
# historiques shell vidés
for f in /root/.bash_history /home/*/.bash_history; do
  [ -s "$f" ] 2>/dev/null && spoil="${spoil:+$spoil; }historique non vide ($f)"
done
[ -z "$spoil" ] && result "SPOILER CHECK" OK || result "SPOILER CHECK" FAILED "$spoil"

# --- Nettoyage : ACCESS PATH a rejoué un spray SSH -> il a réinscrit des traces de
# login (auth.log, btmp/wtmp/lastlog) que --harden avait volontairement vidées.
# On les revide en tout dernier pour rendre au template l'état « journaux vierges »
# (sinon chaque clone étudiant démarrerait avec le spray de vérif du formateur, ce
# qui fausserait l'exercice de détection de jeudi). Sûr : lab-check ne tourne que
# sur la maître pré-template ou un clone de test jetable, jamais sur une VM étudiante.
: > /var/log/auth.log 2>/dev/null || true
: > /var/log/syslog   2>/dev/null || true
: > /var/log/btmp     2>/dev/null || true
: > /var/log/wtmp     2>/dev/null || true
: > /var/log/lastlog  2>/dev/null || true
# lab-check émet aussi des requêtes web (dont /portail-rh-old, fuzz-only) et SMB :
# on efface les journaux nginx/samba qu'elles ont générés — même liste que --harden.
rm -f /var/log/nginx/*.log 2>/dev/null || true
rm -f /var/log/samba/log.*  2>/dev/null || true
# le journal systemd a aussi enregistré le spray de contrôle (sshd/sudo) : on le purge
journalctl --rotate 2>/dev/null || true
journalctl --vacuum-time=1s 2>/dev/null || true

echo
if [ "$FAIL" -eq 0 ]; then
  echo ">>> LAB OK — prêt pour le template."
  echo ">>> Pense à retirer cet outil de la VM :  shred -u \"$0\""
else
  echo ">>> DES CONTRÔLES ONT ÉCHOUÉ — corriger avant de figer le template."
fi
exit "$FAIL"
