#!/usr/bin/env bash
# =============================================================================
# seed-access.sh — Couche MERCREDI (Accès initial) de la cible EDGE01.
# EXTENSION de seed-recon.sh : pose les mots de passe des comptes p.nom et
# ouvre l'authentification SSH par mot de passe, pour le TP « Accès initial ».
#
#   sudo bash seed-access.sh            # provisionne la couche accès
#   sudo bash seed-access.sh --verify   # contrôle les verrous (foothold + garde jeudi)
#   sudo bash seed-access.sh --harden   # prépare l'image dorée avant clonage (voir plus bas)
#   sudo bash seed-access.sh --reset    # reverrouille les comptes, retire le drop-in
#
# ┌─ SÉCURITÉ / DÉPLOIEMENT ─────────────────────────────────────────────────┐
# │ Ce script contient EN CLAIR le mot de passe à dériver (Orvalis2026!) et   │
# │ la matrice qui-tombe/qui-résiste. Il ne doit JAMAIS être lancé ni lisible │
# │ par un étudiant. Modèle : le formateur monte UNE image dorée (seed-recon  │
# │ puis seed-access + --verify), lance --harden, convertit en TEMPLATE       │
# │ Proxmox, puis clone 1 VM par étudiant. Voir le mémo « FORMATEUR -         │
# │ Déploiement EDGE01 ». Prépa récurrente = zéro.                            │
# └──────────────────────────────────────────────────────────────────────────┘
#
# Prérequis : seed-recon.sh a déjà tourné (comptes p.nom créés).
# Debian 12, à lancer en root, dans le lab (jamais en prod). Idempotent.
#
# SCÉNARIO : un mot de passe initial « support » DÉRIVABLE par OSINT
# (ORVALIS + année) n'a pas été changé sur 3 comptes non-admin -> ils tombent
# au password spraying. La DSI et l'ADMIN k.benali ont un mot de passe fort ->
# ils résistent. k.benali est RÉSERVÉ à l'élévation de jeudi.
# =============================================================================
set -euo pipefail

MARKER="/etc/orvalis-edge01.access.seeded"
MARKER_RECON="/etc/orvalis-edge01.seeded"
SECRETS="/root/edge01-access-secrets.txt"
SSHD_DROPIN="/etc/ssh/sshd_config.d/00-edge01.conf"
INIT_PW='Orvalis2026!'                       # mot de passe initial "support", dérivable par OSINT
USERS_ALL=(p.durand s.meyer k.benali l.fontaine m.petit)
declare -A PW=(
  [p.durand]="$INIT_PW"                       # n'a pas changé le défaut  -> TOMBE
  [l.fontaine]="$INIT_PW"                     # n'a pas changé le défaut  -> TOMBE
  [m.petit]="$INIT_PW"                        # n'a pas changé le défaut  -> TOMBE
  [s.meyer]='Sm!9dR4t-Zq81$Kv'               # DSI : a changé            -> RÉSISTE
  [k.benali]='kB7x-Qv2$Ln93!Wp'              # ADMIN : fort, hors wordlist -> RÉSISTE (réservé JEUDI)
)

log(){ printf '\033[1;36m[access]\033[0m %s\n' "$*"; }
err(){ printf '\033[1;31m[access] ERREUR:\033[0m %s\n' "$*" >&2; }
need_root(){ [ "$(id -u)" -eq 0 ] || { err "à lancer en root (sudo)."; exit 1; }; }

require_users(){
  local missing=0
  for u in "${USERS_ALL[@]}"; do
    id "$u" &>/dev/null || { err "compte '$u' absent — lancer d'abord seed-recon.sh"; missing=1; }
  done
  [ "$missing" -eq 0 ] || exit 1
}

# -----------------------------------------------------------------------------
provision(){
  export DEBIAN_FRONTEND=noninteractive
  require_users

  log "Pose des mots de passe (3 comptes gardent le défaut, DSI + admin résistent)..."
  for u in "${USERS_ALL[@]}"; do
    echo "$u:${PW[$u]}" | chpasswd            # note: la valeur est déjà expansée, pas de ré-interprétation du '$'
    passwd -u "$u" >/dev/null 2>&1 || true    # déverrouille l'auth par mot de passe (comptes créés sans -p)
  done

  log "Ouverture de l'auth SSH par mot de passe (drop-in prioritaire 00-)..."
  install -d -m 0755 /etc/ssh/sshd_config.d
  cat > "$SSHD_DROPIN" <<'CONF'
# 00- : lu AVANT 50-cloud-init.conf ; en SSH, la première directive gagne.
PasswordAuthentication yes
KbdInteractiveAuthentication no
PubkeyAuthentication yes
CONF

  # fail2ban casserait le spraying pédagogique -> on le neutralise s'il est présent
  systemctl disable --now fail2ban 2>/dev/null || true

  if sshd -t 2>/dev/null; then
    systemctl restart ssh 2>/dev/null || systemctl restart sshd 2>/dev/null || true
  else
    err "sshd -t a échoué, configuration NON rechargée — vérifier $SSHD_DROPIN"; exit 1
  fi

  # sshpass est requis par --verify (côté formateur). On l'installe MAINTENANT,
  # tant que le réseau est disponible, de façon non fatale — jamais depuis --verify.
  command -v sshpass >/dev/null 2>&1 || apt-get install -y -qq sshpass >/dev/null 2>&1 \
    || err "sshpass non installé (réseau ?) — le --verify hors-ligne sautera les tests SSH"

  # secrets côté formateur uniquement
  umask 077
  { echo "EDGE01 — secrets accès (FORMATEUR) — généré à $(date -Iseconds)";
    echo "mot de passe initial 'support' (dérivable OSINT) : $INIT_PW";
    echo "--- par compte ---";
    for u in "${USERS_ALL[@]}"; do echo "  $u : ${PW[$u]}"; done;
    echo "Tombent au spray : p.durand, l.fontaine, m.petit — Résistent : s.meyer (DSI), k.benali (ADMIN, réservé jeudi)";
  } > "$SECRETS"

  touch "$MARKER"
  log "Couche accès posée. Secrets formateur : $SECRETS"
  echo
  verify || true
}

# -----------------------------------------------------------------------------
verify(){
  # --verify ne dépend PAS du réseau : on n'installe rien ici (sshpass est posé
  # au provisionnement). Si sshpass manque, on saute proprement les tests SSH.
  local O ok out have_sshpass=1 u
  echo "--- Vérification couche accès EDGE01 ---"
  if ! command -v sshpass >/dev/null 2>&1; then
    have_sshpass=0
    echo "  [skip] sshpass absent — installez-le au provisionnement (réseau requis), pas ici."
  fi
  O="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ConnectTimeout=5 -o PreferredAuthentications=password -o PubkeyAuthentication=no"
  ok=0

  if [ "$have_sshpass" -eq 1 ]; then
    # 1) les 3 comptes non-admin CÈDENT au mot de passe initial (matrice 3/2)
    for u in p.durand l.fontaine m.petit; do
      out="$(sshpass -p "$INIT_PW" ssh $O "$u"@127.0.0.1 id 2>/dev/null || true)"
      grep -q 'uid=' <<<"$out" \
        && echo "  [OK]  $u tombe au mot de passe initial" \
        || { echo "  [!!]  $u ne tombe pas (hit attendu manquant)"; ok=1; }
    done

    # 2) la DSI s.meyer RÉSISTE
    out="$(sshpass -p "$INIT_PW" ssh $O s.meyer@127.0.0.1 id 2>/dev/null || true)"
    grep -q 'uid=' <<<"$out" \
      && { echo "  [!!]  s.meyer est tombée au spray ! (mot de passe fort mal posé)"; ok=1; } \
      || echo "  [OK]  s.meyer résiste (DSI)"

    # 3) l'ADMIN k.benali RÉSISTE (verrou jeudi)
    out="$(sshpass -p "$INIT_PW" ssh $O k.benali@127.0.0.1 id 2>/dev/null || true)"
    grep -q 'uid=' <<<"$out" \
      && { echo "  [!!]  k.benali est tombé ! (l'élévation de jeudi serait court-circuitée)"; ok=1; } \
      || echo "  [OK]  k.benali résiste (réservé jeudi)"

    # 4) le foothold N'EST PAS root (verrou jeudi) — une session absente ne doit jamais passer au vert
    out="$(sshpass -p "$INIT_PW" ssh $O p.durand@127.0.0.1 'id -u' 2>/dev/null || true)"
    if [ -z "$out" ]; then
      echo "  [!!]  foothold != root NON vérifié (pas de session p.durand)"; ok=1
    elif [ "$out" = "0" ]; then
      echo "  [!!]  foothold = root : jeudi court-circuité"; ok=1
    else
      echo "  [OK]  foothold non privilégié (uid=$out)"
    fi
  else
    # sshpass absent = matrice NON prouvée : ne jamais conclure « OK » sans elle (faux vert)
    echo "  [!!]  matrice 3/2 + verrous jeudi NON vérifiés (sshpass absent — l'installer au provisionnement)"; ok=1
  fi

  # 5) auth par mot de passe effective (capture puis grep ; sshd -T exige root)
  out="$(sshd -T 2>/dev/null || true)"
  grep -qi '^passwordauthentication yes' <<<"$out" \
    && echo "  [OK]  PasswordAuthentication yes" \
    || { echo "  [!!]  PasswordAuthentication non actif (ou sshd -T lancé sans root)"; ok=1; }

  if [ "$ok" -eq 0 ]; then
    echo ">>> Couche accès OK (matrice 3/2 + verrous jeudi en place)."
  else
    echo ">>> Problème : relancer le provisionnement, ou vérifier sudo / présence de sshpass."
  fi
  return "$ok"
}

# -----------------------------------------------------------------------------
reset(){
  log "Reverrouillage des comptes et retrait de la couche accès..."
  for u in "${USERS_ALL[@]}"; do passwd -l "$u" >/dev/null 2>&1 || true; done
  rm -f "$SSHD_DROPIN" "$SECRETS" "$MARKER"
  systemctl restart ssh 2>/dev/null || systemctl restart sshd 2>/dev/null || true
  log "Reset terminé."
}

# -----------------------------------------------------------------------------
# --harden : prépare l'image dorée AVANT clonage. PRÉSERVE la couche accès
# (comptes, mots de passe, drop-in SSH) mais efface toute trace formateur et
# tout secret, purge les journaux (sinon chaque clone démarrerait avec des
# traces qui fausseraient l'exercice de détection de jeudi), et force la
# régénération de l'identité machine au 1er boot du clone.
# IRRÉVERSIBLE : snapshotter la maître AVANT (elle perd l'outillage seed).
harden(){
  local d u
  log "Durcissement de l'image dorée (l'accès reste posé, les traces formateur partent)..."

  # 1) secrets + scripts seed + marqueurs : rien de sensible ne doit voyager dans le clone
  command -v shred >/dev/null 2>&1 && shred -u "$SECRETS" 2>/dev/null || rm -f "$SECRETS"
  rm -f "$MARKER" "$MARKER_RECON" 2>/dev/null || true
  for d in /root /home /tmp /var/tmp /srv /opt; do
    find "$d" -maxdepth 4 -type f -name 'seed-*.sh' \
      -exec shred -u {} + 2>/dev/null || true
  done
  rm -f "/etc/orvalis-edge01.privesc.seeded" 2>/dev/null || true

  # 2) journaux VIERGES sur le clone (sinon le grep 'Failed password' de jeudi voit nos
  #    traces ; et lastb/last montreraient le spray de vérif contre s.meyer/k.benali).
  : > /var/log/auth.log 2>/dev/null || true
  : > /var/log/syslog   2>/dev/null || true
  : > /var/log/btmp     2>/dev/null || true    # échecs de login (lastb) — spray formateur
  : > /var/log/wtmp     2>/dev/null || true    # sessions réussies (last)
  : > /var/log/lastlog  2>/dev/null || true    # dernière connexion par compte
  rm -f /var/log/nginx/*.log 2>/dev/null || true
  rm -f /var/log/samba/log.*  2>/dev/null || true
  # traces paquets : trahissent le provisionnement « en un bloc » (world-readable !)
  rm -f /var/log/apt/*.log* /var/log/dpkg.log* /var/log/alternatives.log* 2>/dev/null || true
  apt-get clean 2>/dev/null || true                                    # .deb en cache (/var/cache/apt)
  rm -f /var/lib/dpkg/status-old /var/backups/dpkg.* 2>/dev/null || true # sauvegardes dpkg listant les paquets
  journalctl --rotate 2>/dev/null || true
  journalctl --vacuum-time=1s 2>/dev/null || true

  # 3) historique shell de TOUS les comptes présents (root + tout /home/*, dont un
  #    éventuel compte cloud-init/admin 'debian' via lequel les seeds ont tourné en sudo)
  for f in /root/.bash_history /home/*/.bash_history; do : > "$f" 2>/dev/null || true; done

  # 4) identité machine régénérée au 1er boot de chaque clone (clés d'hôte + machine-id)
  rm -f /etc/ssh/ssh_host_* 2>/dev/null || true
  : > /etc/machine-id 2>/dev/null || true
  rm -f /var/lib/dbus/machine-id 2>/dev/null || true
  cat > /etc/systemd/system/edge01-firstboot.service <<'UNIT'
[Unit]
Description=EDGE01 first-boot identity regen
ConditionPathExists=!/etc/ssh/ssh_host_ed25519_key
Before=ssh.service sshd.service
DefaultDependencies=no
After=local-fs.target
[Service]
Type=oneshot
ExecStart=/usr/bin/ssh-keygen -A
ExecStart=/usr/bin/systemd-machine-id-setup
ExecStartPost=/bin/systemctl disable edge01-firstboot.service
[Install]
WantedBy=multi-user.target
UNIT
  systemctl enable edge01-firstboot.service 2>/dev/null || true

  log "Durcissement terminé. Vérifier : 'ls $SECRETS' vide, 'find / -name seed-access.sh' vide."
  err "IMPORTANT : NE PAS redémarrer la maître après --harden — le firstboot régénérerait"
  err "l'identité SUR LA MAÎTRE et figerait des clés SSH/machine-id IDENTIQUES sur tous les"
  err "clones. Passer lab-check.sh (il UTILISE sshpass), PUIS purger sshpass, puis template."
}

# -----------------------------------------------------------------------------
case "${1:-}" in
  --verify) need_root; verify ;;
  --harden) need_root; harden ;;
  --reset)  need_root; reset ;;
  "")       need_root; provision ;;
  *)        echo "Usage: $0 [--verify|--harden|--reset]"; exit 2 ;;
esac
