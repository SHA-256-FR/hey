#!/usr/bin/env bash
# =============================================================================
# seed-recon.sh — Cible d'entraînement EDGE01 (façade ORVALIS), couche MARDI
# (Reconnaissance) — M1 CAR, Semaine Kill Chain.
#
# À lancer en root sur une VM Debian 12 FRAÎCHE, dans le lab isolé (jamais en
# prod), connectée au réseau le temps du montage (installation de paquets).
#
#   sudo bash seed-recon.sh            # provisionne la surface de reconnaissance
#   sudo bash seed-recon.sh --verify   # contrôle toute la surface (TCP/UDP/cert/vhost/SMB)
#   sudo bash seed-recon.sh --reset     # supprime ce que la seed a posé
#
# SURFACE EXPOSÉE (la « vérité terrain » — les docs étudiants ne la révèlent PAS) :
#   22/tcp   SSH   (bannière OpenSSH versionnée)
#   80/tcp   HTTP  site public www.orvalis.fr + vhost interne portail.orvalis.lan
#   443/tcp  HTTPS cert auto-signé (SAN : portail/edge01/www — email admin@orvalis.fr)
#   8080/tcp HTTP  ancien portail v1.2 (legacy, non décommissionné)
#   445/139  SMB   partage 'public' (invité) + 'transfert$' (auth requise)
#   161/udp  SNMP  community 'public' (sysContact k.benali@orvalis.fr)
#
# Idempotent (relançable sans casser l'existant). Aucun secret ici : les mots de
# passe sont posés par seed-access.sh (couche mercredi). Les décors/fausses
# pistes sont volontaires (entraîner le discernement).
# =============================================================================
set -euo pipefail

MARKER="/etc/orvalis-edge01.seeded"
DOMAIN="orvalis.lan"
WWW="/var/www/orvalis"              # site public (www.orvalis.fr / accès par IP)
WWWP="/var/www/orvalis-portail"     # vhost interne portail.orvalis.lan
WWW8080="/var/www/orvalis-old"      # ancien portail (8080)
SMB_PUB="/srv/smb/public"           # partage invité (lecture)
SMB_TR="/srv/smb/transfert"         # partage nécessitant un compte (accès refusé en invité)
CERT_DIR="/etc/ssl/orvalis"
# Comptes LINUX réels (convention p.nom) — alignés sur la page équipe. Ce sont
# les seuls comptes valides ; l'annuaire SMB en cite d'autres qui n'existent PAS
# (ex-salariés) => faux comptes pour l'énumération.
USERS=("p.durand" "s.meyer" "k.benali" "l.fontaine" "m.petit")

# Fichier bureautique embarqué (métadonnées : /Author = s.meyer) pour le levier
# exiftool. Octets déterministes (PDF minimal valide) => robuste au clonage.
PDF_B64="JVBERi0xLjQKMSAwIG9iago8PCAvVHlwZSAvQ2F0YWxvZyAvUGFnZXMgMiAwIFIgPj4KZW5kb2JqCjIgMCBvYmoKPDwgL1R5cGUgL1BhZ2VzIC9LaWRzIFszIDAgUl0gL0NvdW50IDEgPj4KZW5kb2JqCjMgMCBvYmoKPDwgL1R5cGUgL1BhZ2UgL1BhcmVudCAyIDAgUiAvTWVkaWFCb3ggWzAgMCA1OTUgODQyXSAvUmVzb3VyY2VzIDw8IC9Gb250IDw8IC9GMSA1IDAgUiA+PiA+PiAvQ29udGVudHMgNCAwIFIgPj4KZW5kb2JqCjQgMCBvYmoKPDwgL0xlbmd0aCAxOTQgPj4Kc3RyZWFtCkJUIC9GMSAxMiBUZiA2MCA3ODAgVGQgKE9SVkFMSVMgLSBOb3RlIGRlIHNlcnZpY2UgaW50ZXJuZSkgVGogMCAtMjQgVGQgKENvbXB0ZXM6IGZvcm1hdCBwLm5vbSAtIHBvcnRhaWwgaW50ZXJuZTogcG9ydGFpbC5vcnZhbGlzLmxhbikgVGogMCAtMjQgVGQgKERvY3VtZW50IGJ1cmVhdXRpcXVlIC0gZGlmZnVzaW9uIGludGVybmUpIFRqIEVUCmVuZHN0cmVhbQplbmRvYmoKNSAwIG9iago8PCAvVHlwZSAvRm9udCAvU3VidHlwZSAvVHlwZTEgL0Jhc2VGb250IC9IZWx2ZXRpY2EgPj4KZW5kb2JqCjYgMCBvYmoKPDwgL0F1dGhvciAocy5tZXllcikgL1RpdGxlIChPUlZBTElTIC0gTm90ZSBkZSBzZXJ2aWNlIC0gY29tcHRlcyBldCBhY2NlcykgL0NyZWF0b3IgKE9SVkFMSVMgUG9ydGFpbCBSSCB2MikgL1Byb2R1Y2VyIChMaWJyZU9mZmljZSA3LjQpID4+CmVuZG9iagp4cmVmCjAgNwowMDAwMDAwMDAwIDY1NTM1IGYgCjAwMDAwMDAwMDkgMDAwMDAgbiAKMDAwMDAwMDA1OCAwMDAwMCBuIAowMDAwMDAwMTE1IDAwMDAwIG4gCjAwMDAwMDAyNDEgMDAwMDAgbiAKMDAwMDAwMDQ4NiAwMDAwMCBuIAowMDAwMDAwNTU2IDAwMDAwIG4gCnRyYWlsZXIKPDwgL1NpemUgNyAvUm9vdCAxIDAgUiAvSW5mbyA2IDAgUiA+PgpzdGFydHhyZWYKNzEwCiUlRU9GCg=="

log(){ printf '\033[1;36m[recon]\033[0m %s\n' "$*"; }
err(){ printf '\033[1;31m[recon] ERREUR:\033[0m %s\n' "$*" >&2; }
need_root(){ [ "$(id -u)" -eq 0 ] || { err "à lancer en root (sudo)."; exit 1; }; }

# --- garde : réseau + paquets présents après installation -------------------
ensure_pkgs(){
  export DEBIAN_FRONTEND=noninteractive
  log "Installation des paquets (nginx, samba, smbclient, ssh, curl, openssl, snmpd, snmp)..."
  if ! apt-get update -qq; then
    err "apt-get update a échoué — la maître doit avoir accès réseau le temps du montage."; exit 1
  fi
  apt-get install -y -qq nginx samba smbclient openssh-server curl openssl snmpd snmp >/dev/null \
    || { err "installation des paquets échouée (réseau ? miroir ?)."; exit 1; }
  local miss=() c
  for c in nginx smbd smbclient sshd curl openssl snmpd snmpget; do
    command -v "$c" >/dev/null 2>&1 || miss+=("$c")
  done
  [ "${#miss[@]}" -eq 0 ] || { err "binaires manquants après install : ${miss[*]}"; exit 1; }
}

# --- création de compte robuste (noms pointés selon la version de shadow) ----
add_user(){
  local u="$1"
  id "$u" &>/dev/null && return 0
  useradd -m -s /bin/bash "$u" 2>/dev/null && return 0                 # shadow 4.13 (Debian 12)
  useradd --badname -m -s /bin/bash "$u" 2>/dev/null && return 0       # shadow >= 4.14 (Debian 13)
  adduser --quiet --force-badname   --disabled-password --gecos "" --shell /bin/bash "$u" 2>/dev/null && return 0
  adduser --quiet --allow-bad-names --disabled-password --gecos "" --shell /bin/bash "$u"
}

# =============================================================================
provision(){
  need_root
  ensure_pkgs

  # ---- identité machine : hostname + domaine interne (fuite par bannières) --
  log "Hostname edge01 + domaine interne $DOMAIN..."
  hostnamectl set-hostname edge01 2>/dev/null || echo "edge01" > /etc/hostname
  if ! grep -q "edge01.$DOMAIN" /etc/hosts 2>/dev/null; then
    printf '127.0.1.1\tedge01.%s\tedge01\n' "$DOMAIN" >> /etc/hosts
  fi

  # ---- comptes locaux réels (crédibilité de la reco ; mdp posés par seed-access)
  log "Comptes locaux réels (convention p.nom)..."
  local u; for u in "${USERS[@]}"; do add_user "$u"; done

  # ---- certificat auto-signé (SAN informatif) — généré une fois, préservé ---
  log "Certificat TLS auto-signé (SAN : portail/edge01/www, email admin)..."
  mkdir -p "$CERT_DIR"
  if [ ! -s "$CERT_DIR/edge01.crt" ] || [ ! -s "$CERT_DIR/edge01.key" ]; then
    openssl req -x509 -newkey rsa:2048 -nodes -days 3650 \
      -keyout "$CERT_DIR/edge01.key" -out "$CERT_DIR/edge01.crt" \
      -subj "/C=FR/ST=Pays de la Loire/L=Angers/O=ORVALIS SAS/OU=SI/CN=portail.$DOMAIN/emailAddress=admin@orvalis.fr" \
      -addext "subjectAltName=DNS:portail.$DOMAIN,DNS:edge01.$DOMAIN,DNS:www.orvalis.fr" >/dev/null 2>&1 \
      || { err "génération du certificat échouée."; exit 1; }
    chmod 600 "$CERT_DIR/edge01.key"; chmod 644 "$CERT_DIR/edge01.crt"
  fi

  # =========================================================================
  # SITE PUBLIC (port 80/443 par IP ou Host www.orvalis.fr)
  # =========================================================================
  log "Site public ORVALIS + artefacts (robots, backup, uploads, env, dir caché)..."
  mkdir -p "$WWW/admin" "$WWW/backup" "$WWW/uploads" "$WWW/portail-rh-old"
  cat > "$WWW/index.html" <<'HTML'
<!doctype html><html lang="fr"><head><meta charset="utf-8">
<title>ORVALIS — Solutions industrielles</title></head>
<body>
<h1>ORVALIS</h1>
<p>Bienvenue sur le portail du groupe ORVALIS (www.orvalis.fr).</p>
<p><a href="/equipe.html">Notre équipe</a> · <a href="/uploads/">Documents publics</a></p>
<!-- TODO migration : l'ancien portail reste accessible sur le port 8080, à retirer -->
<!-- note dev : ancienne API /api/v1 débranchée depuis la migration, ne plus référencer -->
<!-- RH : nouvelle interface interne sur portail.orvalis.lan (accès annuaire) -->
</body></html>
HTML
  cat > "$WWW/equipe.html" <<'HTML'
<!doctype html><html lang="fr"><head><meta charset="utf-8">
<title>ORVALIS — Notre équipe</title></head><body>
<h1>Notre équipe</h1>
<ul>
<li>Paul Durand — Dirigeant</li>
<li>Sophie Meyer — Directrice des systèmes d'information</li>
<li>Karim Benali — Administrateur systèmes &amp; réseaux</li>
<li>Léa Fontaine — Développeuse</li>
<li>Marc Petit — Support informatique</li>
</ul></body></html>
HTML
  cat > "$WWW/robots.txt" <<'TXT'
User-agent: *
Disallow: /admin
Disallow: /backup
Disallow: /uploads
Disallow: /dev
Disallow: /old-site
TXT
  cat > "$WWW/admin/index.html" <<'HTML'
<!doctype html><html lang="fr"><head><meta charset="utf-8">
<title>ORVALIS — Connexion</title></head><body>
<h1>Espace d'administration</h1>
<form method="post" action="/admin/login">
  <label>Identifiant <input name="user"></label><br>
  <label>Mot de passe <input name="pass" type="password"></label><br>
  <button type="submit">Connexion</button>
</form>
</body></html>
HTML
  cat > "$WWW/backup/notes.txt" <<'TXT'
Sauvegarde portail - notes internes
- penser a retirer le portail 8080 apres migration
- comptes utilisateurs : format p.nom (ex. k.benali)
- portail RH interne : portail.orvalis.lan
TXT
  # --- leurre : ancien dump, compte hérité DÉSACTIVÉ (piste morte) ---
  cat > "$WWW/backup/db_dump_2019.sql.bak" <<'TXT'
-- extrait ancien dump (obsolete, conserve par erreur) --
-- compte herite, supprime lors de la migration :
--   admin_legacy : Welcome2019!   (compte inexistant, ne fonctionne plus)
TXT
  # --- config partielle oubliée : révèle des NOMS internes, aucun accès ---
  cat > "$WWW/backup/config.php.bak" <<'TXT'
<?php
// Sauvegarde de configuration (obsolete) - portail RH
// $DB_HOST = 'db.orvalis.lan';
// $DB_NAME = 'portail_rh';
// $DB_USER = 'svc_portail';
// $DB_PASS = '***retire de la sauvegarde***';   // ne jamais versionner un secret
// APP = 'portail-rh v2'  |  auth = annuaire interne
TXT
  # --- fichier d'exemple d'environnement (placeholders, pas de secret) ---
  cat > "$WWW/.env.example" <<'TXT'
APP_NAME=portail-rh
APP_ENV=production
APP_HOST=portail.orvalis.lan
DB_HOST=db.orvalis.lan
DB_USER=svc_portail
DB_PASS=change_me_before_prod
# copier en .env et renseigner les vraies valeurs (ne pas committer)
TXT
  # --- /uploads : document public anodin (piste morte) ---
  cat > "$WWW/uploads/plaquette_orvalis.txt" <<'TXT'
ORVALIS - plaquette commerciale (document public)
Solutions industrielles et services numeriques associes. Contact : contact@orvalis.fr
TXT
  # --- répertoire NON listé dans robots : ne se trouve que par fuzzing ------
  cat > "$WWW/portail-rh-old/index.html" <<'HTML'
<!doctype html><html lang="fr"><head><meta charset="utf-8">
<title>Ancienne interface RH</title></head><body>
<h1>Ancienne interface RH (hors service)</h1>
<p>Migrée vers l'interface interne portail.orvalis.lan.</p>
<!-- ancien format d'identifiant : prenom.nom (ex. paul.durand) - remplace par p.nom -->
</body></html>
HTML

  # =========================================================================
  # VHOST INTERNE portail.orvalis.lan (login cul-de-sac + teaser monitoring)
  # =========================================================================
  log "Vhost interne portail.orvalis.lan..."
  mkdir -p "$WWWP"
  cat > "$WWWP/index.html" <<'HTML'
<!doctype html><html lang="fr"><head><meta charset="utf-8">
<title>ORVALIS — Portail RH (interne)</title></head><body>
<h1>Portail RH ORVALIS — accès réservé</h1>
<form method="post" action="/login">
  <label>Identifiant <input name="user"></label><br>
  <label>Mot de passe <input name="pass" type="password"></label><br>
  <button type="submit">Se connecter</button>
</form>
<!-- authentification via annuaire interne - voir /monitoring (restreint) -->
</body></html>
HTML

  # ---- ancien portail (8080) -----------------------------------------------
  log "Ancien portail legacy (8080)..."
  mkdir -p "$WWW8080"
  cat > "$WWW8080/index.html" <<'HTML'
<!doctype html><html lang="fr"><head><meta charset="utf-8">
<title>ORVALIS Portail v1.2</title></head><body>
<h1>ORVALIS Portail v1.2 (ancienne version)</h1>
<p>Interface interne — usage réservé.</p>
<!-- endpoint interne /api/v1/status hors service depuis la migration -->
<!-- ancien annuaire : identifiants au format prenom.nom -->
</body></html>
HTML

  # ---- vhosts nginx (80 + 443) ---------------------------------------------
  cat > /etc/nginx/sites-available/orvalis <<NGINX
server {
    listen 80 default_server;
    listen 443 ssl default_server;
    server_name www.orvalis.fr _;
    ssl_certificate     $CERT_DIR/edge01.crt;
    ssl_certificate_key $CERT_DIR/edge01.key;
    root $WWW;
    index index.html;
    autoindex on;                 # listing pour /backup, /uploads, /portail-rh-old
    location / { try_files \$uri \$uri/ =404; }
}
NGINX
  cat > /etc/nginx/sites-available/orvalis-portail <<NGINX
server {
    listen 80;
    listen 443 ssl;
    server_name portail.$DOMAIN;
    ssl_certificate     $CERT_DIR/edge01.crt;
    ssl_certificate_key $CERT_DIR/edge01.key;
    root $WWWP;
    index index.html;
    add_header X-Internal-App "portail-rh v2" always;
    location /monitoring/ { return 403; }   # teaser : accès restreint
    location / { try_files \$uri \$uri/ =404; }
}
NGINX
  cat > /etc/nginx/sites-available/orvalis-old <<NGINX
server {
    listen 8080;
    server_name _;
    root $WWW8080;
    index index.html;
    location / { try_files \$uri \$uri/ =404; }
}
NGINX
  ln -sf /etc/nginx/sites-available/orvalis         /etc/nginx/sites-enabled/orvalis
  ln -sf /etc/nginx/sites-available/orvalis-portail /etc/nginx/sites-enabled/orvalis-portail
  ln -sf /etc/nginx/sites-available/orvalis-old     /etc/nginx/sites-enabled/orvalis-old
  rm -f /etc/nginx/sites-enabled/default
  chown -R www-data:www-data "$WWW" "$WWWP" "$WWW8080"
  nginx -t >/dev/null 2>&1 || { err "nginx -t a échoué — configuration NON rechargée."; exit 1; }
  systemctl enable --now nginx >/dev/null 2>&1 || true
  systemctl reload nginx 2>/dev/null || systemctl restart nginx

  # =========================================================================
  # SAMBA : partage 'public' (invité) + 'transfert$' (auth requise)
  # =========================================================================
  log "Partages SMB (public invité + transfert auth)..."
  mkdir -p "$SMB_PUB" "$SMB_TR"
  cat > "$SMB_PUB/procedure.txt" <<'TXT'
PROCEDURE INTERNE - COMPTES UTILISATEURS
Les comptes suivent le format p.nom (initiale du prenom + nom).
Le mot de passe initial est communique par le support informatique.
Merci de le changer a la premiere connexion.
TXT
  cat > "$SMB_PUB/notes_reunion.txt" <<'TXT'
Notes de reunion - comite SI (extrait)
- migration du portail en cours
- prevoir la fermeture du partage public apres la bascule
TXT
  cat > "$SMB_PUB/anciens_acces.txt" <<'TXT'
Anciens acces (archive) - NE PLUS UTILISER
- compte de test t.old / Test1234 : DESACTIVE
- ces identifiants ne sont plus valides depuis la refonte
TXT
  # --- annuaire élargi : noms au format p.nom, DONT des ex-salariés (faux comptes) ---
  cat > "$SMB_PUB/annuaire_interne.csv" <<'TXT'
identifiant;nom;service;statut
p.durand;Paul Durand;Direction;actif
s.meyer;Sophie Meyer;DSI;actif
k.benali;Karim Benali;Infrastructure;actif
l.fontaine;Lea Fontaine;Developpement;actif
m.petit;Marc Petit;Support;actif
c.girard;Camille Girard;Commercial;actif
j.moreau;Julien Moreau;Comptabilite;parti 2023
a.rousseau;Alex Rousseau;Stage;parti 2024
TXT
  cat > "$SMB_PUB/README_transfert.txt" <<'TXT'
Partage 'transfert' : reserve au personnel.
L'acces anonyme est desactive - il faut un compte du domaine (format p.nom).
TXT
  # --- document bureautique (métadonnées : /Author = s.meyer) ---
  printf '%s' "$PDF_B64" | base64 -d > "$SMB_PUB/note_service.pdf" 2>/dev/null \
    || err "génération du PDF de métadonnées échouée (non bloquant)."
  echo "Espace de transfert interne - contenu reserve au personnel." > "$SMB_TR/depot.txt"
  chmod -R 0755 "$SMB_PUB"; chmod -R 0750 "$SMB_TR"

  [ -f /etc/samba/smb.conf.orvalis-bak ] || cp /etc/samba/smb.conf /etc/samba/smb.conf.orvalis-bak
  cat > /etc/samba/smb.conf <<SMB
[global]
   workgroup = ORVALIS
   server string = EDGE01 (edge01.$DOMAIN)
   map to guest = Bad User
   guest account = nobody
   security = user

[public]
   path = $SMB_PUB
   browseable = yes
   read only = yes
   guest ok = yes

[transfert\$]
   path = $SMB_TR
   browseable = yes
   read only = yes
   guest ok = no
   valid users = p.durand s.meyer k.benali l.fontaine m.petit
SMB
  systemctl enable --now smbd nmbd >/dev/null 2>&1 || systemctl enable --now smbd >/dev/null 2>&1 || true
  systemctl restart smbd 2>/dev/null || true
  systemctl restart nmbd 2>/dev/null || true

  # =========================================================================
  # SNMP (161/udp, community public) — sysContact révèle l'email de l'admin
  # =========================================================================
  log "SNMP community 'public' (sysContact k.benali@orvalis.fr)..."
  [ -f /etc/snmp/snmpd.conf.orvalis-bak ] || \
    { [ -f /etc/snmp/snmpd.conf ] && cp /etc/snmp/snmpd.conf /etc/snmp/snmpd.conf.orvalis-bak; } || true
  cat > /etc/snmp/snmpd.conf <<SNMPCONF
# EDGE01 - SNMP en lecture seule (community 'public') - lab pédagogique
agentAddress udp:161
rocommunity public default
sysName    edge01.$DOMAIN
sysContact k.benali@orvalis.fr
sysLocation Angers - Salle serveurs
sysServices 72
SNMPCONF
  systemctl enable --now snmpd >/dev/null 2>&1 || true
  systemctl restart snmpd 2>/dev/null || true

  # ---- SSH -----------------------------------------------------------------
  systemctl enable --now ssh >/dev/null 2>&1 || systemctl enable --now sshd >/dev/null 2>&1 || true

  touch "$MARKER"
  log "Provisionnement reconnaissance terminé."
  echo
  verify || true
}

# =============================================================================
verify(){
  local ok=0 out
  echo "--- Vérification surface EDGE01 (reconnaissance) ---"

  # 1) ports TCP attendus
  local p
  for p in 22 80 443 8080 445; do
    if (exec 3<>"/dev/tcp/127.0.0.1/$p") 2>/dev/null; then
      echo "  [OK]  TCP $p ouvert"; exec 3>&- || true
    else echo "  [!!]  TCP $p FERMÉ"; ok=1; fi
  done

  # 2) SNMP (UDP 161) — répond avec le sysName attendu
  if command -v snmpget >/dev/null 2>&1; then
    out="$(snmpget -v2c -c public -t 2 -r 1 127.0.0.1 sysName.0 2>/dev/null || true)"
    grep -q 'edge01' <<<"$out" \
      && echo "  [OK]  SNMP 161/udp répond (sysName edge01)" \
      || { echo "  [!!]  SNMP 161/udp KO"; ok=1; }
  else
    echo "  [!!]  client snmp absent (paquet 'snmp' manquant)"; ok=1
  fi

  # 3) certificat TLS : SAN portail.orvalis.lan présent
  if command -v openssl >/dev/null 2>&1; then
    out="$(echo | openssl s_client -connect 127.0.0.1:443 -servername portail."$DOMAIN" 2>/dev/null \
           | openssl x509 -noout -text 2>/dev/null || true)"
    grep -q "portail.$DOMAIN" <<<"$out" \
      && echo "  [OK]  cert HTTPS 443 (SAN portail.$DOMAIN)" \
      || { echo "  [!!]  cert HTTPS/SAN KO"; ok=1; }
  fi

  # 4) site public : robots + /admin
  out="$(curl -fs "http://127.0.0.1/robots.txt" 2>/dev/null || true)"
  grep -q "/admin" <<<"$out" \
    && echo "  [OK]  robots.txt (site public)" || { echo "  [!!]  robots.txt KO"; ok=1; }
  out="$(curl -fs "http://127.0.0.1/admin/" 2>/dev/null || true)"
  grep -qi "connexion" <<<"$out" \
    && echo "  [OK]  page /admin présente" || { echo "  [!!]  /admin KO"; ok=1; }

  # 5) vhost interne : Host portail.orvalis.lan sert la page RH
  out="$(curl -fs -H "Host: portail.$DOMAIN" "http://127.0.0.1/" 2>/dev/null || true)"
  grep -qi "Portail RH" <<<"$out" \
    && echo "  [OK]  vhost portail.$DOMAIN répond" || { echo "  [!!]  vhost portail KO"; ok=1; }

  # 6) répertoire caché (fuzz-only) accessible en direct
  out="$(curl -fs "http://127.0.0.1/portail-rh-old/" 2>/dev/null || true)"
  grep -qi "Ancienne interface RH" <<<"$out" \
    && echo "  [OK]  dir caché /portail-rh-old (fuzz-only)" || { echo "  [!!]  dir caché KO"; ok=1; }

  # 7) SMB : partage 'public' visible ET 'transfert$' listé mais refusé en invité
  if command -v smbclient >/dev/null 2>&1; then
    out="$(smbclient -L //127.0.0.1/ -N 2>/dev/null || true)"
    grep -q "public"    <<<"$out" && echo "  [OK]  SMB 'public' visible"        || { echo "  [!!]  SMB public KO"; ok=1; }
    grep -q "transfert" <<<"$out" && echo "  [OK]  SMB 'transfert\$' listé"      || { echo "  [!!]  SMB transfert non listé"; ok=1; }
    out="$(smbclient //127.0.0.1/transfert\$ -N -c 'ls' 2>&1 || true)"
    grep -qiE 'NT_STATUS_ACCESS_DENIED|NT_STATUS_LOGON_FAILURE' <<<"$out" \
      && echo "  [OK]  'transfert\$' refuse l'accès invité (auth requise)" \
      || { echo "  [!!]  'transfert\$' accessible en invité (fuite)"; ok=1; }
  else
    echo "  [!!]  smbclient absent"; ok=1
  fi

  [ "$ok" -eq 0 ] && echo ">>> Surface EDGE01 OK." || echo ">>> Des éléments manquent (relancer sans --verify)."
  return "$ok"
}

# =============================================================================
reset(){
  need_root
  log "Nettoyage de la couche reconnaissance..."
  systemctl stop nginx smbd nmbd snmpd 2>/dev/null || true
  rm -rf "$WWW" "$WWWP" "$WWW8080" "$SMB_PUB" "$SMB_TR" "$CERT_DIR"
  rm -f /etc/nginx/sites-enabled/orvalis /etc/nginx/sites-enabled/orvalis-portail /etc/nginx/sites-enabled/orvalis-old \
        /etc/nginx/sites-available/orvalis /etc/nginx/sites-available/orvalis-portail /etc/nginx/sites-available/orvalis-old
  local u; for u in "${USERS[@]}"; do userdel -r "$u" 2>/dev/null || true; done
  [ -f /etc/samba/smb.conf.orvalis-bak ] && mv /etc/samba/smb.conf.orvalis-bak /etc/samba/smb.conf || true
  [ -f /etc/snmp/snmpd.conf.orvalis-bak ] && mv /etc/snmp/snmpd.conf.orvalis-bak /etc/snmp/snmpd.conf || true
  rm -f "$MARKER"
  systemctl restart nginx 2>/dev/null || true
  systemctl restart snmpd 2>/dev/null || true
  log "Reset terminé."
}

# =============================================================================
case "${1:-}" in
  --verify) verify ;;
  --reset)  reset ;;
  "")       provision ;;
  *)        echo "Usage: $0 [--verify|--reset]"; exit 2 ;;
esac
